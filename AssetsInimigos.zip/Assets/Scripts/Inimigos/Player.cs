using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
	
	
	public int Vida = 10;
	public int speed = 7;
	private Rigidbody2D rb;
	private Vector2 nullVec;
	public GameObject attackArea;
	
    // Start is called before the first frame update
    void Start()
    {
        rb = this.gameObject.GetComponent<Rigidbody2D>();
		Vector2 nullVec = new Vector2(0,0);
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxisRaw("Horizontal");
		float moveVertical = Input.GetAxisRaw("Vertical");
		Vector2 movement = new Vector2(moveHorizontal, moveVertical);
		rb.velocity = (movement*speed);
		
		if(moveHorizontal == 0 && moveVertical == 0){
			rb.velocity = nullVec;
		}
		
		
		if(Input.GetKey(KeyCode.Space)){
			attackArea.SetActive (true);
		}else{
			attackArea.SetActive (false);
		}
    }
}
